<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="bootstrap/bootstrap/css/bootstrap.css" type="text/css" />

        <title></title>
    </head>
    <body>
    <center>
        <h1>Add New Job</h1>
        <form name="search" action="insert.php" method="post">
            <table align="center">
                <tbody>
                    <tr>
                        <td><input type="text" name="query"></td>
                    </tr>
                </tbody>

            </table>
        </form>

    </center>
    <?php
    // put your code here
    ?>
</body>
</html>
