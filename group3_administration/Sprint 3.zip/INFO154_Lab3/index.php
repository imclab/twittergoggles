<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" href="bootstrap/bootstrap/css/bootstrap.css" type="text/css" />
    </head>
    <body>


    <center>
        <h1>Job Administration</h1>
            <table align="center">
                <tbody>
                    <tr>
                        <td><a href="view.php">View/Update Jobs</a></td>
                        <td><center>Search</center></td>
                    </tr>
                    <tr>
                        <td><a href="insertform.php">Add New</a></td>
                        <td><form name="search" action="search.php" method="post"><input type="text" name="query"></form></td>
                    </tr>
                </tbody>

            </table>
    </center>

</body>
</html>