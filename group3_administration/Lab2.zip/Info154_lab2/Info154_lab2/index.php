<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
       
        
    <center>
    <table border="1">
<tr>
<td><center><form name="search" action="insert.php" method="post">
            Add Job:
            <input type="text" name="query">
            <input type="submit" value="submit">
        </form></center></td>
<td><a href="view.php">View Jobs</a></td>
</tr>

</table>
        
    </center>
    </br>

</body>
</html>
